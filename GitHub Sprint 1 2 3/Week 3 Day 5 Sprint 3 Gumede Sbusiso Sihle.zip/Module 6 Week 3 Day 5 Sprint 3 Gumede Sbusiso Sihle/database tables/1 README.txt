Here is my database tables

Instructions:

1.Download the databases to your computer.

2.First you have to install MySQL Workbench on your machine.

3.Create database called testdb.

4.Go to your database that you created above in your MySQL workbench.

5.Inside your database you will find tables right click that and look for "table data import wizard".

6.It will take you the file path where you should browser the databases you have downloaded above and the select that database you want and press next.

7.Select the option say "Creating new table" and then press next

8.Press next until it say finish then you press finish.


Thank you !!!!



